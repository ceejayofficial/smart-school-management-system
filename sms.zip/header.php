<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold text-white" href="dashboard.php">📲 SMS Sender</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active text-white" href="dashboard.php">Dashboard</a>
        </li>
        <!-- Logout with text and optional icon -->
        <li class="nav-item">
          <a class="nav-link text-white logout-btn px-4 py-2 border-2 border-white rounded-lg flex items-center hover:bg-danger hover:text-white transition duration-300 ease-in-out" href="#" id="logoutBtn">
            <!-- Optional Text Logout -->
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="js/header.js" ></script>

<script>
// Ensure Bootstrap's JavaScript is working for the dropdown on smaller screens
document.addEventListener('DOMContentLoaded', function () {
  var myCollapse = document.getElementById('navbarNav');
  var bsCollapse = new bootstrap.Collapse(myCollapse, {
    toggle: false
  });
  
  // Logout confirmation
  document.getElementById('logoutBtn').addEventListener('click', function (e) {
    e.preventDefault();
    Swal.fire({
      title: 'Are you sure?',
      text: "You are about to log out. Please confirm if you want to end your session.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, log me out',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = 'logout.php';
      }
    });
  });
});
</script>
