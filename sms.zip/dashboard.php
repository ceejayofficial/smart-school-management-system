
<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit();
}

// Check if terms accepted
if (!isset($_SESSION['accepted_terms']) || $_SESSION['accepted_terms'] !== true) {
    header("Location: terms.php");
    exit();
}


?>

<?php include("header.php"); ?>

<?php include("dashboard-header.php"); ?>




<body>

  <div class="container">
    <div class="dashboard-card">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="header-title">📤 Send SMS</div>
        <a href="index.php" id="logoutBtn" class="btn btn-outline-danger btn-sm btn-logout">Home</a>
        </div>

      <form id="smsForm" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="sender_id" class="form-label">Sender ID</label>
          <select class="form-select" id="sender_id" name="sender_id" required>
            <option value="">Select Sender ID</option>
            <?php
              require __DIR__ . '/vendor/autoload.php';
              use Dotenv\Dotenv;

              $dotenv = Dotenv::createImmutable(__DIR__);
              $dotenv->load();

              $senderIds = [
                  $_ENV['MNOTIFY_SENDER_ID_1'],
              ];

              foreach ($senderIds as $senderId) {
                  echo "<option value='$senderId'>$senderId</option>";
              }
            ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="message" class="form-label">Message</label>
          <textarea class="form-control" id="message" name="message" rows="4" required placeholder="Type your message here..."></textarea>
        </div>

        <div class="mb-3">
          <label for="contacts_file" class="form-label">Upload Excel File (.xlsx)</label>
          <input type="file" class="form-control" id="contacts_file" name="contacts_file" accept=".xlsx" required>
          <div class="form-text">Upload an Excel file with contact numbers</div>
        </div>

        <div class="d-grid">
          <button type="submit" class="btn btn-success"> Send </button>
        </div>
      </form>
    </div>
  </div>

  <!-- JavaScript -->
  <script>
    document.getElementById('smsForm').addEventListener('submit', async function(e) {
      e.preventDefault();

      const form = e.target;
      const formData = new FormData(form);

      Swal.fire({
        title: 'Sending...',
        text: 'Please wait while we process your request.',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
      });

      try {
        const response = await fetch('send_sms.php', {
          method: 'POST',
          body: formData
        });

        const result = await response.json();
        Swal.close();

        if (result.status === 'success') {
          Swal.fire({
            icon: 'success',
            title: 'Messages Sent Successfully!',
            html: result.html,
            width: 700
          });
          form.reset();
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: result.message || 'An error occurred while sending messages.'
          });
        }
      } catch (error) {
        Swal.close();
        Swal.fire({
          icon: 'error',
          title: 'Unexpected Error',
          text: 'Failed to connect to the server. Please try again.'
        });
      }
    });

  </script>

</body>

<!-- <script src="js/script.js" ></script> -->

</html>
<?php include("footer.php"); ?>