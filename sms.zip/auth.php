<?php

session_start();


if (isset($_SESSION['admin']) && $_SESSION['admin'] === true) {
    header("Location: dashboard.php");
    exit();  
} 

if(!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit();
}
