<!-- footer.php -->
<footer class="bg-light text-center text-muted py-3 mt-5 border-top">
  <div class="container">
    <small>&copy; <?php echo date("Y"); ?> SMS Sender Admin Dashboard. All rights reserved.</small>
  </div>
</footer>
