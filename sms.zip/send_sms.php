<?php

require __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use Dotenv\Dotenv;

header('Content-Type: application/json');

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$apiKey = $_ENV['MNOTIFY_API_KEY'] ?? null;
$smsUrl = $_ENV['MNOTIFY_SMS_URL'] ?? null;

// DB credentials
$dbHost = $_ENV['DB_HOST'] ?? 'localhost';
$dbUser = $_ENV['DB_USER'] ?? 'root';
$dbPass = $_ENV['DB_PASS'] ?? '';
$dbName = $_ENV['DB_NAME'] ?? 'sms_logs';

// Connect to database
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

function isValidPhoneNumber($phone)
{
    $originalPhone = $phone;

    // Allow digits and optional "+" at beginning
    if (!preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
        return 'Phone number must start with 0 or + and have 10-15 digits';
    }

    if (strpos($phone, '+') === 0) {
        $digits = preg_replace('/\D/', '', $phone);
        return strlen($digits) >= 10 ? true : 'International number must have at least 10 digits';
    }

    if (strpos($phone, '0') === 0) {
        return strlen($phone) === 10 ? true : 'Local number must have exactly 10 digits';
    }

    return 'Phone number format not recognized';
}

function logToDatabase($conn, $to, $message, $status, $response)
{
    $stmt = $conn->prepare("INSERT INTO sms_history (recipient, message, status, response, sent_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssss", $to, $message, $status, $response);
    $stmt->execute();
    $stmt->close();
}

if (!$apiKey || !$smsUrl) {
    echo json_encode(['status' => 'error', 'message' => 'Missing API configuration']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senderId = $_POST['sender_id'] ?? null;
    $message = trim($_POST['message']);

    if (!$senderId || !$message) {
        echo json_encode(['status' => 'error', 'message' => 'Sender ID and message are required']);
        exit;
    }

    if (!isset($_FILES['contacts_file']) || $_FILES['contacts_file']['error'] !== 0) {
        echo json_encode(['status' => 'error', 'message' => 'File upload failed']);
        exit;
    }

    $tmpFile = $_FILES['contacts_file']['tmp_name'];

    try {
        $spreadsheet = IOFactory::load($tmpFile);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        $errorReport = "<ul style='text-align:left'>";
        $allSuccess = true;
        $successCount = 0;
        $failureCount = 0;

        foreach ($rows as $index => $row) {
            if ($index === 0) continue;

            $contact = isset($row[0]) ? trim($row[0]) : '';
            if ($contact === '') {
                continue; // skip empty rows
            }
            $validationResult = isValidPhoneNumber($contact);


            if ($validationResult !== true) {
                $errorReport .= "<li><strong>To:</strong> $contact<br><strong>Status:</strong> $validationResult</li>";
                logToDatabase($conn, $contact, $message, 'failed', $validationResult);
                $allSuccess = false;
                $failureCount++;
                continue;
            }

            $url = $smsUrl
                . '?key=' . urlencode($apiKey)
                . '&to=' . urlencode($contact)
                . '&msg=' . urlencode($message)
                . '&sender_id=' . urlencode($senderId);

            $response = @file_get_contents($url);

            if ($response !== false) {
                $successCount++;
                logToDatabase($conn, $contact, $message, 'success', $response);
            } else {
                $errorMsg = 'Failed to send SMS';
                $errorReport .= "<li><strong>To:</strong> $contact<br><strong>Status:</strong> $errorMsg</li>";
                logToDatabase($conn, $contact, $message, 'failed', $errorMsg);
                $allSuccess = false;
                $failureCount++;
            }
        }

        $errorReport .= "</ul>";

        if ($failureCount > 0) {
            $failureMessage = $failureCount === 1 ? '1 contact was invalid or failed to send.' : "$failureCount contacts were invalid or failed to send.";
            echo json_encode([
                'status' => 'error',
                'message' => "Some contacts failed to send. Success: $successCount | $failureMessage",
                'html' => $errorReport
            ]);
        } elseif ($allSuccess) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Message sent successfully!'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => "Message failed to send.",
                'html' => $errorReport
            ]);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Spreadsheet error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
