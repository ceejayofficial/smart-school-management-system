
<?php

session_start(); 
include("db.php");

if (isset($_SESSION['admin']) && $_SESSION['admin'] === true) {
  header("Location: dashboard.php");
  exit();  
}

 


// Error message if login fails
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the input values
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username exists in the database
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // If a user is found
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userId, $dbUsername, $dbPassword);
        $stmt->fetch();

        // Verify the plain text password
        if ($password === $dbPassword) {
            $_SESSION['admin'] = true;
            $_SESSION['user_id'] = $userId;  
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}


?>

<?php
include("default-header.php");
?>
<body>

  <div class="container">
    <!-- Left Text Section -->
    <div class="text-section">
      <h1>SMS Sender</h1>
      <p>Effortlessly communicate with your users. Send SMS, receive updates, and stay connected in a seamless experience.</p>
    </div>

    <!-- Login Form Section -->
    <div class="login-card">
      <h4 class="login-title">Login</h4>
      <form method="POST" novalidate>
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" name="username" class="form-control" id="username" required />
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <input type="password" name="password" class="form-control" id="password" required />
        </div>
        <button type="submit" class="login-btn">Login</button>
      </form>
    </div>
  </div>

  <?php if (!empty($error)) : ?>
  <script>
    Swal.fire({
      icon: 'error',
      title: 'Login Failed',
      text: '<?php echo $error; ?>'
    });
  </script>

  
  <?php endif; ?>

</body>
</html>
